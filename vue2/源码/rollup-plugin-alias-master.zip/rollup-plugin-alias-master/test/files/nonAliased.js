export default 24;
