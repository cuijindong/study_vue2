import nonAliased from './nonAliased';
import fancyNumber from 'fancyNumber';
import anotherFancyNumber from './anotherFancyNumber';
import anotherNumber from './numberFolder/anotherNumber';
import moreNumbers from 'numberFolder/anotherNumber';

export default fancyNumber + anotherFancyNumber + nonAliased + anotherNumber + moreNumbers;

